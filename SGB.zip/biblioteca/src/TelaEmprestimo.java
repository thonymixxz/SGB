import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TelaEmprestimo extends JFrame {

    private JTextField txtNomeCliente;
    private JTextField txtTituloLivro;
    private JTable tabelaEmprestimos;
    private DefaultTableModel modeloTabela;

    public TelaEmprestimo() {
        setTitle("Gerenciamento de Empréstimos");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(5,2,10,10));

        painel.add(new JLabel("Nome do Cliente:"));
        txtNomeCliente = new JTextField();
        painel.add(txtNomeCliente);

        painel.add(new JLabel("Título do Livro:"));
        txtTituloLivro = new JTextField();
        painel.add(txtTituloLivro);

        JButton btnEmprestar = new JButton("Registrar Empréstimo");
        painel.add(new JLabel(""));
        painel.add(btnEmprestar);

        add(painel, BorderLayout.NORTH);

        String[] colunas = {"Cliente", "Livro Emprestado", "Data do Empréstimo"};
        modeloTabela = new DefaultTableModel(colunas, 0);
        tabelaEmprestimos = new JTable(modeloTabela);
        JScrollPane scrollTabela = new JScrollPane(tabelaEmprestimos);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Empréstimos Ativos"));

        add(scrollTabela, BorderLayout.CENTER);

        JPanel painelAcoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnDevolver = new JButton("Registrar Devolução / Recebimento");
        painelAcoes.add(btnDevolver);
        add(painelAcoes, BorderLayout.SOUTH);

        btnEmprestar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarEmprestimo();
            }
        });

        btnDevolver.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registrarDevolucao();
            }
        });
    }

    private void registrarEmprestimo() {
        String cliente = txtNomeCliente.getText().trim();
        String livro = txtTituloLivro.getText().trim();

        if (cliente.isEmpty() || livro.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha o nome do cliente e o livro!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate dataAtual = LocalDate.now();
        DateTimeFormatter formatador = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String dataFormatada = dataAtual.format(formatador);

        modeloTabela.addRow(new Object[]{cliente, livro, dataFormatada});

        txtNomeCliente.setText("");
        txtTituloLivro.setText("");

        JOptionPane.showMessageDialog(this, "Empréstimo registrado");
    }

    private void registrarDevolucao() {
        int linhaSelecionada = tabelaEmprestimos.getSelectedRow();

        if (linhaSelecionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecione um empréstimo na tabela para dar baixa!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        modeloTabela.removeRow(linhaSelecionada);
        JOptionPane.showMessageDialog(this, " O Livro disponível novamente.");
    }
}
