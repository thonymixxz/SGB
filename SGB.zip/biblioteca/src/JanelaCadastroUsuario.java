import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JanelaCadastroUsuario extends JFrame {

    private JTextField txtNome;
    private JTextField txtIdade;
    private JTextField txtCpf;
    private JTable tabelaUsuarios;
    private DefaultTableModel modeloTabela;

    public JanelaCadastroUsuario() {
        setTitle("Cadastro de Usuários");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // --- PAINEL DE FORMULÁRIO (TOPO) ---
        JPanel painel = new JPanel();
        painel.setLayout(new GridLayout(5,2,10,10));

        painel.add(new JLabel("Nome:"));
        txtNome = new JTextField();
        painel.add(txtNome);

        painel.add(new JLabel("Idade:"));
        txtIdade = new JTextField();
        painel.add(txtIdade);

        painel.add(new JLabel("CPF:"));
        txtCpf = new JTextField();
        painel.add(txtCpf);

        JButton btnSalvar = new JButton("Salvar Usuário");
        painel.add(new JLabel(""));
        painel.add(btnSalvar);

        add(painel, BorderLayout.NORTH);

        String[] colunas = {"Nome", "Idade", "CPF"};
        modeloTabela = new DefaultTableModel(colunas, 0);
        tabelaUsuarios = new JTable(modeloTabela);
        JScrollPane scrollTabela = new JScrollPane(tabelaUsuarios);
        scrollTabela.setBorder(BorderFactory.createTitledBorder("Usuários Cadastrados"));

        add(scrollTabela, BorderLayout.CENTER);

        btnSalvar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                salvarUsuario();
            }
        });
    }

    private void salvarUsuario() {
        String nome = txtNome.getText().trim();
        String idade = txtIdade.getText().trim();
        String cpf = txtCpf.getText().trim();


        if (nome.isEmpty() || idade.isEmpty() || cpf.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Preencha todos os campos!", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }

        modeloTabela.addRow(new Object[]{nome, idade, cpf});

        txtNome.setText("");
        txtIdade.setText("");
        txtCpf.setText("");

        JOptionPane.showMessageDialog(this, "Usuário cadastrado!");
    }
}