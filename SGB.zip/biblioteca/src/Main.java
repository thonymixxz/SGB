public class Main {

    public static void main(String[] args) {

        javax.swing.SwingUtilities.invokeLater(() -> {

            JanelaMenu menuPrincipal = new JanelaMenu();

            menuPrincipal.setVisible(true);


        });
    }
}