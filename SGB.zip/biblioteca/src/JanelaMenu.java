import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class JanelaMenu extends JFrame {

    public JanelaMenu() {
        setTitle("Sistema de Biblioteca");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JMenuBar barraMenu = new JMenuBar();

        JMenu menuUsuario = new JMenu("Usuários");
        JMenu menuLivro = new JMenu("Livros");
        JMenu menuEmprestimo = new JMenu("Empréstimos");


        JMenuItem itemCadastrarUsuario = new JMenuItem("Cadastrar Usuário");
        JMenuItem itemCadastrarLivro = new JMenuItem("Cadastrar Livro");
        JMenuItem itemVerEmprestimos = new JMenuItem("Ver Empréstimos");


        menuUsuario.add(itemCadastrarUsuario);
        menuLivro.add(itemCadastrarLivro);
        menuEmprestimo.add(itemVerEmprestimos);

        barraMenu.add(menuUsuario);
        barraMenu.add(menuLivro);
        barraMenu.add(menuEmprestimo);

        setJMenuBar(barraMenu);

        itemCadastrarUsuario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JanelaCadastroUsuario janelUs = new JanelaCadastroUsuario();
                janelUs.setVisible(true);

                JOptionPane.showMessageDialog(JanelaMenu.this, "Abrindo tela de Cadastro de Usuário...");
            }
        });

        itemCadastrarLivro.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaBiblioteca telaBib = new TelaBiblioteca();
                telaBib.setVisible(true);

                JOptionPane.showMessageDialog(JanelaMenu.this, "Abrindo tela de Cadastro de Livro...");
            }
        });

        itemVerEmprestimos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaEmprestimo telaemp = new TelaEmprestimo();
                telaemp.setVisible(true);

                JOptionPane.showMessageDialog(JanelaMenu.this, "Abrindo tela de Visualização de Empréstimos...");
            }
        });
    }

    public static void main(String[] args) {

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new JanelaMenu().setVisible(true);
            }
        });
    }
}
